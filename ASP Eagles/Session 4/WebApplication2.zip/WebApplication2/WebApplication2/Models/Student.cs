﻿namespace WebApplication2.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string? Stu_name { get; set; }
        public string? Stu_gender { get; set; }
        public double Stu_avg { get; set; }
        public string? Stu_dob { get; set; }

        public Student(int Id, string Stu_name, string Stu_gender, double Stu_avg, string Stu_dob)
        {
            this.Id = Id;
            this.Stu_name = Stu_name;
            this.Stu_gender = Stu_gender;
            this.Stu_avg = Stu_avg;
            this.Stu_dob = Stu_dob;
        }
    }
}
