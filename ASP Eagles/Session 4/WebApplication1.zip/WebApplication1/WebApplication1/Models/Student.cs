﻿namespace WebApplication1.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string? Stu_name { get; set; }
        public string? Stu_gender { get; set; }
        public double Stu_avg { get; set; }
        public string? Stu_dob { get; set; }

        public Student(int ID_, string Stu_name_, string Stu_gender_ , double Stu_avg_ , string Stu_dob_)
        {
            Id = ID_;
            Stu_name = Stu_name_;
            Stu_gender = Stu_gender_;
            Stu_avg = Stu_avg_;
            Stu_dob = Stu_dob_;
        }
    }
}
