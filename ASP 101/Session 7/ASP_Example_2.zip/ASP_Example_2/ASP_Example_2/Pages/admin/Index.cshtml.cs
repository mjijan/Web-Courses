using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP_Example_2.Pages.admin
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
