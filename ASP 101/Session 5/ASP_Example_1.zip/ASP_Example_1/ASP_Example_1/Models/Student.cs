﻿namespace ASP_Example_1.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string? Stu_Name { get; set; }
        public string? Stu_Gender { get; set; }
        public float Stu_Avg { get; set; }

        public Student(int s_id , string s_name , string s_gender , float s_avg)
        {
            Id = s_id ;
            Stu_Name = s_name ;
            Stu_Gender = s_gender ;
            Stu_Avg = s_avg ;
        }
    }
}
