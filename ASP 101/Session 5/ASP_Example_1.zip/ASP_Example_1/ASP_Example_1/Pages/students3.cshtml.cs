using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP_Example_1.Pages
{
    public class students3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
