using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP_Example_1.Pages
{
    public class StudentsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
