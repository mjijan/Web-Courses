﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ASP_MOVIES_2.Data;
using ASP_MOVIES_2.Models;

namespace ASP_MOVIES_2.Pages.Movies
{
    public class CreateModel : PageModel
    {
        private readonly ASP_MOVIES_2.Data.ASP_MOVIES_2Context _context;

        public CreateModel(ASP_MOVIES_2.Data.ASP_MOVIES_2Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Movie Movie { get; set; } = default!;

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {

            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Movie.Add(Movie);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }





        //public IActionResult OnPostAsync()
        //{
        //    _context.Movie.Add(Movie);
        //    _context.SaveChanges();
        //    return RedirectToPage("./Index");
        //}











    }
}
