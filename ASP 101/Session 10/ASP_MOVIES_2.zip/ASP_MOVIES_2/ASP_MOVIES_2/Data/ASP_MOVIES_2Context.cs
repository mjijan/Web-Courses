﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ASP_MOVIES_2.Models;

namespace ASP_MOVIES_2.Data
{
    public class ASP_MOVIES_2Context : DbContext
    {
        public ASP_MOVIES_2Context (DbContextOptions<ASP_MOVIES_2Context> options)
            : base(options)
        {
        }

        public DbSet<ASP_MOVIES_2.Models.Movie> Movie { get; set; } = default!;
    }
}
