﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ASP_MOVIES_2.Migrations
{
    /// <inheritdoc />
    public partial class mig_movies2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "img",
                table: "Movie",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "img",
                table: "Movie");
        }
    }
}
