using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP_101_A.Pages
{
    public class stu3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
