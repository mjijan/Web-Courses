using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication3.Pages
{
    public class StudentsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
