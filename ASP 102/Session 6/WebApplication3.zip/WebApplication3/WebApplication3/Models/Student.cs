﻿namespace WebApplication3.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string? Stu_name { get; set; }
        public float Stu_avg { get; set; }
        public string? Stu_gender { get; set; }
        public string? Stu_dob { get; set; }

        public Student ()
        {

        }

        public Student(int Id1 , string Stu_name1, float Stu_avg1 , string Stu_gender1 , string Stu_dob1)
        {
            this.Id = Id1;
            this.Stu_name = Stu_name1;
            this.Stu_avg = Stu_avg1;
            this.Stu_gender = Stu_gender1;
            this.Stu_dob = Stu_dob1;
        }


    }
}
