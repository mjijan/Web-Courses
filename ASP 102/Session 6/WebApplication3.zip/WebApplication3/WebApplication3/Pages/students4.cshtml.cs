using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication3.Pages
{
    public class students4Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
